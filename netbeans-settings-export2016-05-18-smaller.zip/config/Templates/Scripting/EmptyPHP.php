<!--
    Copyright	: ${date}, ${time}
    Author		: ${user}
	Creative Common Non-Commercial no derivatives license <https://creativecommons.org/licenses/by-nc-sa/4.0/>
-->

