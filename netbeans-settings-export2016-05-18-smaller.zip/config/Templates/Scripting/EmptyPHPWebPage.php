${doctype}
<!--
/* 
    Copyright	: ${date}, ${time}
    Author		: ${user}
	Creative Common Non-Commercial no derivatives license <https://creativecommons.org/licenses/by-nc-sa/4.0/>
*/
-->
<html>
    <head>
        <meta charset="${project.encoding}">
        <title></title>
    </head>
    <body>
        <?php
        // put your code here
        ?>
    </body>
</html>
