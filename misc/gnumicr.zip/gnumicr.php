<?php
$type='TrueTypeUnicode';
$name='GnuMICR';
$desc=array('Ascent'=>702,'Descent'=>0,'CapHeight'=>702,'Flags'=>32,'FontBBox'=>'[10 0 720 702]','ItalicAngle'=>0,'StemV'=>70,'MissingWidth'=>600);
$up=-125;
$ut=50;
$dw=600;
$cw=array(
32=>751,48=>751,49=>751,50=>751,51=>751,52=>751,53=>751,54=>751,55=>751,56=>751,
57=>751,65=>751,66=>751,67=>751,68=>751,169=>751);
$enc='';
$diff='';
$file='gnumicr.z';
$ctg='gnumicr.ctg.z';
$originalsize=8924;
// --- EOF ---