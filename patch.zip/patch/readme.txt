Current version of patched files: Drupal 7.17

The files with names starting with "0" are the originals. The others are our improved (patched) files.

The .js files go in misc/.
The .inc files go in includes/.
user.module goes in modules/user/.
